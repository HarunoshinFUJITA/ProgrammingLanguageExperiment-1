int conv_table_20140(char string[100], int cards[8][15]);
int conv_20140_table(int cards[8][15], char string[100]);
