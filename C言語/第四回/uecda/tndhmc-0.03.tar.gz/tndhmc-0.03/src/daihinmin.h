void search_low_card(int out_cards[8][15],int my_cards[8][15],int joker_flag);

